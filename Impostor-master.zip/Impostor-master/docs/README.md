# Impostor Documentation

1. [Running the server](Running-the-server.md)
2. [Server configuration](Server-configuration.md)
3. [Building-from-source](Building-from-source.md)
4. [Frequently answered questions](FAQ.md)