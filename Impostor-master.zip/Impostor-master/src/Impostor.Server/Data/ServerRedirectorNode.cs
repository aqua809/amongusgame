﻿namespace Impostor.Server.Data
{
    public class ServerRedirectorNode
    {
        public string Ip { get; set; }
        public ushort Port { get; set; }
    }
}