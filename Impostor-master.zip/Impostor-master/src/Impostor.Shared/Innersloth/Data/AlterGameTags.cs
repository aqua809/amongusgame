﻿namespace Impostor.Shared.Innersloth.Data
{
    public enum AlterGameTags : byte
    {
        ChangePrivacy = 1
    }
}