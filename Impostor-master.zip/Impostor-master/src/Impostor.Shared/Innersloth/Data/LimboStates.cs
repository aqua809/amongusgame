﻿namespace Impostor.Shared.Innersloth.Data
{
    public enum LimboStates
    {
        PreSpawn,
        NotLimbo,
        WaitingForHost,
    }
}